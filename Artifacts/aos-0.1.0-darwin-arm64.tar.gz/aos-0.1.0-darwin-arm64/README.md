# aos-cli

Minimal CLI for running the AOS scan pipeline outside the desktop app.

## Install

Install with Homebrew:

```bash
brew tap AOS-HZ/tap https://github.com/AOS-HZ/homebrew-tap
brew install aos-cli
```

## Build

```bash
cargo build --release
```

Install the executable as `aos`:

```bash
cargo install --path .
```

To build without network access, use the vendored dependency tree:

```bash
cargo build --release --locked --offline
```

## Commands

Run the default scan flow:

```bash
aos scan
```

Scan specific roots:

```bash
aos scan ~/.codex ~/.agents
```

Scan a specific skills directory:

```bash
aos scan ~/.codex/skills
```

Write the final result to JSON:

```bash
aos scan --output ./tmp/scan.json --json
```

Run environment checks:

```bash
aos doctor
```

Run repository audit against an arbitrary local codebase:

```bash
aos repo-scan ~/my-agent-project
```

Write the repository audit result to JSON:

```bash
aos repo-scan ~/my-agent-project --json --output ./tmp/repo-scan.json
```

## Notes

- `aos scan` runs the full flow: local scan, skill sync, and cloud analysis.
- `aos repo-scan` runs the native `aos-core` repository audit engine against a local project path.
- `aos doctor` checks the storage file, server connectivity, and default scan roots.
